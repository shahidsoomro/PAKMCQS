/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'pak-green': {
          50: '#f0fdf4',
          100: '#dcfce7',
          500: '#01411c',
          600: '#013919',
          700: '#013016',
          800: '#012713',
          900: '#011e0f',
        },
        'pak-white': '#ffffff',
        'pak-moon': '#ffffff',
        'pak-crescent': '#01411c',
      }
    },
  },
  plugins: [],
};