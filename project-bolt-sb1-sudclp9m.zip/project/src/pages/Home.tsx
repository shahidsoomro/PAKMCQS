import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Award, BarChart, Clock, AlignCenterVertical as Certificate, Users } from 'lucide-react';

const Home: React.FC = () => {
  return (
    <div className="bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-800 to-green-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-28">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-6">
                Master Pakistan Studies with Interactive MCQs
              </h1>
              <p className="text-xl mb-8">
                Enhance your knowledge of Pakistan's history, culture, and politics through our comprehensive quiz platform.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Link 
                  to="/register" 
                  className="bg-white text-green-800 px-6 py-3 rounded-md font-medium text-center hover:bg-gray-100 transition"
                >
                  Get Started
                </Link>
                <Link 
                  to="/quizzes" 
                  className="border border-white text-white px-6 py-3 rounded-md font-medium text-center hover:bg-green-700 transition"
                >
                  Explore Quizzes
                </Link>
              </div>
            </div>
            <div className="hidden md:block">
              <img 
                src="https://images.pexels.com/photos/3184644/pexels-photo-3184644.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Students studying" 
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Choose Our Platform?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We provide a comprehensive learning experience with features designed to enhance your knowledge of Pakistan Studies.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition">
              <div className="bg-green-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-6">
                <BookOpen className="h-8 w-8 text-green-800" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Comprehensive Quizzes</h3>
              <p className="text-gray-600">
                Access a wide range of MCQs covering history, geography, politics, culture, and economy of Pakistan.
              </p>
            </div>
            
            {/* Feature 2 */}
            <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition">
              <div className="bg-green-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-6">
                <Award className="h-8 w-8 text-green-800" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Earn Certificates</h3>
              <p className="text-gray-600">
                Complete quizzes and earn downloadable certificates to showcase your knowledge and achievements.
              </p>
            </div>
            
            {/* Feature 3 */}
            <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-lg transition">
              <div className="bg-green-100 p-3 rounded-full w-14 h-14 flex items-center justify-center mb-6">
                <BarChart className="h-8 w-8 text-green-800" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Track Progress</h3>
              <p className="text-gray-600">
                Monitor your performance with detailed analytics and see how you rank on our leaderboards.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-gray-100 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Get started in just a few simple steps and begin your journey to mastering Pakistan Studies.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Step 1 */}
            <div className="text-center">
              <div className="bg-white p-6 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6 shadow-md">
                <span className="text-2xl font-bold text-green-800">1</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Create Account</h3>
              <p className="text-gray-600">
                Register for free and set up your personal profile.
              </p>
            </div>
            
            {/* Step 2 */}
            <div className="text-center">
              <div className="bg-white p-6 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6 shadow-md">
                <span className="text-2xl font-bold text-green-800">2</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Choose Quiz</h3>
              <p className="text-gray-600">
                Browse categories and select a quiz that interests you.
              </p>
            </div>
            
            {/* Step 3 */}
            <div className="text-center">
              <div className="bg-white p-6 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6 shadow-md">
                <span className="text-2xl font-bold text-green-800">3</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Take Quiz</h3>
              <p className="text-gray-600">
                Answer questions within the time limit and submit your answers.
              </p>
            </div>
            
            {/* Step 4 */}
            <div className="text-center">
              <div className="bg-white p-6 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-6 shadow-md">
                <span className="text-2xl font-bold text-green-800">4</span>
              </div>
              <h3 className="text-xl font-semibold mb-3">Get Certificate</h3>
              <p className="text-gray-600">
                View your results and download your achievement certificate.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Explore Quiz Categories</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Dive into various aspects of Pakistan Studies with our categorized quizzes.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Category 1 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition">
              <img 
                src="https://images.pexels.com/photos/2774556/pexels-photo-2774556.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="History" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">History</h3>
                <p className="text-gray-600 mb-4">
                  Test your knowledge about Pakistan's independence movement, key historical events, and notable figures.
                </p>
                <Link 
                  to="/quizzes" 
                  className="text-green-800 font-medium hover:text-green-700"
                >
                  Explore History Quizzes →
                </Link>
              </div>
            </div>
            
            {/* Category 2 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition">
              <img 
                src="https://images.pexels.com/photos/269724/pexels-photo-269724.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Geography" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Geography</h3>
                <p className="text-gray-600 mb-4">
                  Challenge yourself with questions about Pakistan's landscapes, natural resources, climate, and regions.
                </p>
                <Link 
                  to="/quizzes" 
                  className="text-green-800 font-medium hover:text-green-700"
                >
                  Explore Geography Quizzes →
                </Link>
              </div>
            </div>
            
            {/* Category 3 */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition">
              <img 
                src="https://images.pexels.com/photos/1550337/pexels-photo-1550337.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Politics" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Politics</h3>
                <p className="text-gray-600 mb-4">
                  Learn about Pakistan's political system, constitution, governance structure, and political history.
                </p>
                <Link 
                  to="/quizzes" 
                  className="text-green-800 font-medium hover:text-green-700"
                >
                  Explore Politics Quizzes →
                </Link>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <Link 
              to="/quizzes" 
              className="bg-green-800 text-white px-6 py-3 rounded-md font-medium hover:bg-green-700 transition"
            >
              View All Categories
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-gray-100 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">What Our Users Say</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Hear from students who have improved their knowledge using our platform.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full bg-green-200 flex items-center justify-center mr-4">
                  <span className="text-green-800 font-bold">AK</span>
                </div>
                <div>
                  <h4 className="font-semibold">Ahmed Khan</h4>
                  <p className="text-gray-600 text-sm">University Student</p>
                </div>
              </div>
              <p className="text-gray-600">
                "This platform helped me prepare for my Pakistan Studies exam. The quizzes are comprehensive and cover all important topics. I improved my grade significantly!"
              </p>
            </div>
            
            {/* Testimonial 2 */}
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full bg-green-200 flex items-center justify-center mr-4">
                  <span className="text-green-800 font-bold">SF</span>
                </div>
                <div>
                  <h4 className="font-semibold">Sara Fatima</h4>
                  <p className="text-gray-600 text-sm">High School Teacher</p>
                </div>
              </div>
              <p className="text-gray-600">
                "I recommend this platform to all my students. The variety of questions and instant feedback make it an excellent learning tool. The certificates also motivate my students."
              </p>
            </div>
            
            {/* Testimonial 3 */}
            <div className="bg-white p-8 rounded-lg shadow-md">
              <div className="flex items-center mb-4">
                <div className="h-12 w-12 rounded-full bg-green-200 flex items-center justify-center mr-4">
                  <span className="text-green-800 font-bold">UM</span>
                </div>
                <div>
                  <h4 className="font-semibold">Usman Malik</h4>
                  <p className="text-gray-600 text-sm">CSS Aspirant</p>
                </div>
              </div>
              <p className="text-gray-600">
                "Preparing for CSS exams became much easier with this platform. The timed quizzes helped me improve my speed and accuracy. The detailed explanations for each answer are invaluable."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-green-800 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Test Your Knowledge?</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Join thousands of students who are mastering Pakistan Studies through our interactive quizzes.
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link 
              to="/register" 
              className="bg-white text-green-800 px-6 py-3 rounded-md font-medium hover:bg-gray-100 transition"
            >
              Sign Up Now
            </Link>
            <Link 
              to="/quizzes" 
              className="border border-white text-white px-6 py-3 rounded-md font-medium hover:bg-green-700 transition"
            >
              Browse Quizzes
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;