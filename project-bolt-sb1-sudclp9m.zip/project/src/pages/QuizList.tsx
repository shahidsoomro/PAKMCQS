import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Clock, Award, Filter, Search, ChevronDown } from 'lucide-react';

// Mock data for quizzes
const mockQuizzes = [
  {
    id: '101',
    title: 'Pakistan Independence Movement',
    category: 'History',
    description: 'Test your knowledge about the events leading to Pakistan\'s independence in 1947.',
    questions: 20,
    difficulty: 'Medium',
    estimatedTime: '15 mins',
    attempts: 1243,
    rating: 4.8
  },
  {
    id: '102',
    title: 'Geography of Pakistan',
    category: 'Geography',
    description: 'Explore the diverse geographical features of Pakistan from mountains to deserts.',
    questions: 15,
    difficulty: 'Easy',
    estimatedTime: '10 mins',
    attempts: 987,
    rating: 4.5
  },
  {
    id: '103',
    title: 'Political System of Pakistan',
    category: 'Politics',
    description: 'Learn about Pakistan\'s political structure, constitution, and governance.',
    questions: 25,
    difficulty: 'Hard',
    estimatedTime: '20 mins',
    attempts: 756,
    rating: 4.7
  },
  {
    id: '104',
    title: 'Cultural Heritage of Pakistan',
    category: 'Culture',
    description: 'Discover the rich cultural heritage, traditions, and arts of Pakistan.',
    questions: 18,
    difficulty: 'Medium',
    estimatedTime: '15 mins',
    attempts: 632,
    rating: 4.6
  },
  {
    id: '105',
    title: 'Economic Development of Pakistan',
    category: 'Economy',
    description: 'Understand Pakistan\'s economic journey, challenges, and achievements since independence.',
    questions: 22,
    difficulty: 'Hard',
    estimatedTime: '18 mins',
    attempts: 521,
    rating: 4.4
  },
  {
    id: '106',
    title: 'Pakistan's Foreign Relations',
    category: 'Politics',
    description: 'Explore Pakistan\'s diplomatic relations with neighboring countries and global powers.',
    questions: 20,
    difficulty: 'Medium',
    estimatedTime: '15 mins',
    attempts: 489,
    rating: 4.5
  }
];

// Categories for filtering
const categories = [
  'All Categories',
  'History',
  'Geography',
  'Politics',
  'Culture',
  'Economy'
];

// Difficulty levels for filtering
const difficultyLevels = [
  'All Difficulties',
  'Easy',
  'Medium',
  'Hard'
];

const QuizList: React.FC = () => {
  const [quizzes, setQuizzes] = useState(mockQuizzes);
  const [filteredQuizzes, setFilteredQuizzes] = useState(mockQuizzes);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [selectedDifficulty, setSelectedDifficulty] = useState('All Difficulties');
  const [sortBy, setSortBy] = useState('popular'); // 'popular', 'newest', 'rating'

  // Apply filters and search
  useEffect(() => {
    let result = [...quizzes];
    
    // Apply search
    if (searchTerm) {
      result = result.filter(quiz => 
        quiz.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        quiz.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Apply category filter
    if (selectedCategory !== 'All Categories') {
      result = result.filter(quiz => quiz.category === selectedCategory);
    }
    
    // Apply difficulty filter
    if (selectedDifficulty !== 'All Difficulties') {
      result = result.filter(quiz => quiz.difficulty === selectedDifficulty);
    }
    
    // Apply sorting
    if (sortBy === 'popular') {
      result.sort((a, b) => b.attempts - a.attempts);
    } else if (sortBy === 'rating') {
      result.sort((a, b) => b.rating - a.rating);
    }
    // For 'newest', we would normally sort by date, but our mock data doesn't have dates
    
    setFilteredQuizzes(result);
  }, [quizzes, searchTerm, selectedCategory, selectedDifficulty, sortBy]);

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Explore Quizzes</h1>
          <p className="mt-2 text-gray-600">
            Browse our collection of Pakistan Studies quizzes and test your knowledge.
          </p>
        </div>
        
        {/* Filters and search */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Search */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search quizzes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              />
            </div>
            
            {/* Category filter */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter className="h-5 w-5 text-gray-400" />
              </div>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm appearance-none"
              >
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <ChevronDown className="h-5 w-5 text-gray-400" />
              </div>
            </div>
            
            {/* Difficulty filter */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Award className="h-5 w-5 text-gray-400" />
              </div>
              <select
                value={selectedDifficulty}
                onChange={(e) => setSelectedDifficulty(e.target.value)}
                className="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm appearance-none"
              >
                {difficultyLevels.map(level => (
                  <option key={level} value={level}>{level}</option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <ChevronDown className="h-5 w-5 text-gray-400" />
              </div>
            </div>
            
            {/* Sort by */}
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm appearance-none"
              >
                <option value="popular">Most Popular</option>
                <option value="newest">Newest</option>
                <option value="rating">Highest Rated</option>
              </select>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <ChevronDown className="h-5 w-5 text-gray-400" />
              </div>
            </div>
          </div>
        </div>
        
        {/* Quiz list */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredQuizzes.length > 0 ? (
            filteredQuizzes.map(quiz => (
              <div key={quiz.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition">
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className="bg-green-100 p-2 rounded-full">
                      <BookOpen className="h-6 w-6 text-green-800" />
                    </div>
                    <div className="flex items-center">
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        {quiz.difficulty}
                      </span>
                    </div>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{quiz.title}</h3>
                  <p className="text-sm text-gray-500 mb-4">{quiz.description}</p>
                  <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <span>{quiz.questions} questions</span>
                    <span className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {quiz.estimatedTime}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-sm text-gray-500">{quiz.attempts} attempts</span>
                      <div className="flex items-center mt-1">
                        <div className="flex">
                          {[...Array(5)].map((_, i) => (
                            <svg 
                              key={i}
                              className={`h-4 w-4 ${i < Math.floor(quiz.rating) ? 'text-yellow-400' : 'text-gray-300'}`}
                              fill="currentColor"
                              viewBox="0 0 20 20"
                            >
                              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                            </svg>
                          ))}
                        </div>
                        <span className="ml-1 text-sm text-gray-500">{quiz.rating}</span>
                      </div>
                    </div>
                    <Link 
                      to={`/quiz/${quiz.id}`}
                      className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-800 hover:bg-green-700"
                    >
                      Start Quiz
                    </Link>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No quizzes found</h3>
              <p className="text-gray-500">
                Try adjusting your search or filter criteria.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default QuizList;