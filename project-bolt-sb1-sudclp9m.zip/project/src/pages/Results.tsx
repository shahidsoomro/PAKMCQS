import React, { useRef } from 'react';
import { useParams, useLocation, Link } from 'react-router-dom';
import { Award, Download, Clock, CheckCircle, XCircle, ArrowLeft, Share2 } from 'lucide-react';
import { format } from 'date-fns';
import { useReactToPdf } from 'react-to-pdf';

const Results: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const location = useLocation();
  const certificateRef = useRef<HTMLDivElement>(null);
  
  // Get results from location state
  const { 
    score = 80, 
    totalQuestions = 10, 
    correctAnswers = 8, 
    timeTaken = 600, // in seconds
    quizTitle = 'Pakistan Independence Movement',
    quizCategory = 'History'
  } = location.state || {};
  
  // Format time taken
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins} min ${secs} sec`;
  };
  
  // Generate PDF certificate
  const { toPdf, targetRef } = useReactToPdf({
    filename: `certificate-${id}.pdf`,
    options: {
      format: 'a4',
      orientation: 'landscape',
    },
  });
  
  // Get current date
  const currentDate = format(new Date(), 'MMMM d, yyyy');
  
  // Determine pass/fail status
  const isPassed = score >= 60;
  
  // Get badge based on score
  const getBadge = () => {
    if (score >= 90) return 'Excellent';
    if (score >= 80) return 'Very Good';
    if (score >= 70) return 'Good';
    if (score >= 60) return 'Satisfactory';
    return 'Needs Improvement';
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Results header */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Quiz Results</h1>
              <p className="text-gray-600 mt-1">{quizTitle} • {quizCategory}</p>
            </div>
            <div className="mt-4 md:mt-0">
              <Link 
                to="/quizzes"
                className="inline-flex items-center text-green-800 hover:text-green-700"
              >
                <ArrowLeft className="h-4 w-4 mr-1" />
                Back to Quizzes
              </Link>
            </div>
          </div>
        </div>
        
        {/* Score summary */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="text-center mb-6">
            <div className={`inline-flex items-center justify-center h-24 w-24 rounded-full ${
              isPassed ? 'bg-green-100' : 'bg-red-100'
            } mb-4`}>
              <span className={`text-3xl font-bold ${
                isPassed ? 'text-green-800' : 'text-red-800'
              }`}>
                {score}%
              </span>
            </div>
            <h2 className="text-xl font-semibold text-gray-900">
              {isPassed ? 'Congratulations!' : 'Better luck next time!'}
            </h2>
            <p className="text-gray-600 mt-1">
              {isPassed 
                ? 'You have successfully passed the quiz.' 
                : 'You did not pass the quiz. Keep practicing!'}
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                <span className="text-sm text-gray-600">Correct Answers</span>
              </div>
              <p className="text-2xl font-semibold mt-2">{correctAnswers} / {totalQuestions}</p>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center">
                <Clock className="h-5 w-5 text-blue-600 mr-2" />
                <span className="text-sm text-gray-600">Time Taken</span>
              </div>
              <p className="text-2xl font-semibold mt-2">{formatTime(timeTaken)}</p>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center">
                <Award className="h-5 w-5 text-purple-600 mr-2" />
                <span className="text-sm text-gray-600">Badge Earned</span>
              </div>
              <p className="text-2xl font-semibold mt-2">{getBadge()}</p>
            </div>
          </div>
        </div>
        
        {/* Certificate */}
        {isPassed && (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-900">Your Certificate</h2>
              <div className="flex space-x-2">
                <button
                  onClick={() => toPdf()}
                  className="inline-flex items-center px-3 py-1.5 bg-green-800 text-white rounded-md hover:bg-green-700"
                >
                  <Download className="h-4 w-4 mr-1" />
                  Download
                </button>
                <button
                  className="inline-flex items-center px-3 py-1.5 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300"
                >
                  <Share2 className="h-4 w-4 mr-1" />
                  Share
                </button>
              </div>
            </div>
            
            {/* Certificate Preview */}
            <div 
              ref={targetRef} 
              className="bg-white border-8 border-double border-green-800 p-8 rounded-lg shadow-md"
            >
              <div className="text-center">
                <div className="flex justify-center mb-4">
                  <Award className="h-16 w-16 text-green-800" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900 mb-2">Certificate of Achievement</h2>
                <p className="text-gray-600 mb-6">This is to certify that</p>
                <p className="text-2xl font-semibold text-green-800 mb-6">John Doe</p>
                <p className="text-gray-600 mb-6">
                  has successfully completed the quiz on
                </p>
                <p className="text-xl font-bold text-gray-900 mb-6">{quizTitle}</p>
                <p className="text-gray-600 mb-8">
                  with a score of <span className="font-semibold">{score}%</span>
                </p>
                
                <div className="flex justify-between items-center mt-12">
                  <div className="text-left">
                    <p className="text-gray-900 font-medium">Date</p>
                    <p className="text-gray-600">{currentDate}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-gray-900 font-medium">PakStudy MCQs</p>
                    <p className="text-gray-600">Certificate ID: {id}-{Date.now().toString().slice(-6)}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* Actions */}
        <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
          <Link 
            to={`/quiz/${id}`}
            className="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-800 hover:bg-green-700"
          >
            Retake Quiz
          </Link>
          <Link 
            to="/quizzes"
            className="inline-flex items-center justify-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            Try Another Quiz
          </Link>
          <Link 
            to="/leaderboard"
            className="inline-flex items-center justify-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            View Leaderboard
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Results;