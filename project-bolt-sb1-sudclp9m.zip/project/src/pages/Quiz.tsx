import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Clock, AlertCircle, ChevronLeft, ChevronRight, Flag, CheckCircle, HelpCircle } from 'lucide-react';

// Mock quiz data
const mockQuizData = {
  '101': {
    id: '101',
    title: 'Pakistan Independence Movement',
    category: 'History',
    description: 'Test your knowledge about the events leading to Pakistan\'s independence in 1947.',
    totalQuestions: 10,
    timeLimit: 15, // in minutes
    questions: [
      {
        id: 1,
        text: 'When was Pakistan officially declared an independent nation?',
        options: [
          { id: 'a', text: 'August 14, 1947' },
          { id: 'b', text: 'August 15, 1947' },
          { id: 'c', text: 'March 23, 1940' },
          { id: 'd', text: 'June 3, 1947' }
        ],
        correctAnswer: 'a'
      },
      {
        id: 2,
        text: 'Who was the first Governor-General of Pakistan?',
        options: [
          { id: 'a', text: 'Liaquat Ali Khan' },
          { id: 'b', text: 'Muhammad Ali Jinnah' },
          { id: 'c', text: 'Khawaja Nazimuddin' },
          { id: 'd', text: 'Iskander Mirza' }
        ],
        correctAnswer: 'b'
      },
      {
        id: 3,
        text: 'Which resolution is considered the basis for the creation of Pakistan?',
        options: [
          { id: 'a', text: 'Delhi Resolution' },
          { id: 'b', text: 'Lahore Resolution' },
          { id: 'c', text: 'Karachi Resolution' },
          { id: 'd', text: 'Rawalpindi Resolution' }
        ],
        correctAnswer: 'b'
      },
      {
        id: 4,
        text: 'When was the All-India Muslim League founded?',
        options: [
          { id: 'a', text: '1885' },
          { id: 'b', text: '1900' },
          { id: 'c', text: '1906' },
          { id: 'd', text: '1913' }
        ],
        correctAnswer: 'c'
      },
      {
        id: 5,
        text: 'Who was the first Prime Minister of Pakistan?',
        options: [
          { id: 'a', text: 'Muhammad Ali Jinnah' },
          { id: 'b', text: 'Liaquat Ali Khan' },
          { id: 'c', text: 'Khawaja Nazimuddin' },
          { id: 'd', text: 'I.I. Chundrigar' }
        ],
        correctAnswer: 'b'
      },
      {
        id: 6,
        text: 'Which plan was announced by Lord Mountbatten for the partition of India?',
        options: [
          { id: 'a', text: 'June 3 Plan' },
          { id: 'b', text: 'August Plan' },
          { id: 'c', text: 'Cabinet Mission Plan' },
          { id: 'd', text: 'Wavell Plan' }
        ],
        correctAnswer: 'a'
      },
      {
        id: 7,
        text: 'When was the Objective Resolution adopted by the Constituent Assembly of Pakistan?',
        options: [
          { id: 'a', text: '1947' },
          { id: 'b', text: '1949' },
          { id: 'c', text: '1952' },
          { id: 'd', text: '1956' }
        ],
        correctAnswer: 'b'
      },
      {
        id: 8,
        text: 'Which of the following was NOT a part of Pakistan at independence?',
        options: [
          { id: 'a', text: 'East Bengal' },
          { id: 'b', text: 'West Punjab' },
          { id: 'c', text: 'Kashmir' },
          { id: 'd', text: 'Sindh' }
        ],
        correctAnswer: 'c'
      },
      {
        id: 9,
        text: 'Who was the president of the All-India Muslim League at the time of partition?',
        options: [
          { id: 'a', text: 'Muhammad Ali Jinnah' },
          { id: 'b', text: 'Liaquat Ali Khan' },
          { id: 'c', text: 'Allama Iqbal' },
          { id: 'd', text: 'Chaudhry Khaliquzzaman' }
        ],
        correctAnswer: 'a'
      },
      {
        id: 10,
        text: 'Which of the following was the first capital of Pakistan?',
        options: [
          { id: 'a', text: 'Lahore' },
          { id: 'b', text: 'Islamabad' },
          { id: 'c', text: 'Rawalpindi' },
          { id: 'd', text: 'Karachi' }
        ],
        correctAnswer: 'd'
      }
    ]
  }
};

const Quiz: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const [quiz, setQuiz] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [flagged, setFlagged] = useState<number[]>([]);
  const [timeLeft, setTimeLeft] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Fetch quiz data
  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      if (id && mockQuizData[id]) {
        setQuiz(mockQuizData[id]);
        setTimeLeft(mockQuizData[id].timeLimit * 60); // Convert minutes to seconds
        setLoading(false);
      } else {
        setError('Quiz not found');
        setLoading(false);
      }
    }, 1000);
  }, [id]);
  
  // Timer countdown
  useEffect(() => {
    if (!quiz || timeLeft <= 0) return;
    
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, [quiz, timeLeft]);
  
  // Format time as MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  // Handle answer selection
  const handleAnswerSelect = (questionId: number, answerId: string) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answerId
    }));
  };
  
  // Toggle flagged question
  const toggleFlag = (questionId: number) => {
    setFlagged(prev => {
      if (prev.includes(questionId)) {
        return prev.filter(id => id !== questionId);
      } else {
        return [...prev, questionId];
      }
    });
  };
  
  // Navigate to next question
  const goToNextQuestion = () => {
    if (currentQuestion < quiz.questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    }
  };
  
  // Navigate to previous question
  const goToPrevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };
  
  // Navigate to specific question
  const goToQuestion = (index: number) => {
    setCurrentQuestion(index);
  };
  
  // Submit quiz
  const handleSubmit = () => {
    setIsSubmitting(true);
    
    // Calculate score
    const totalQuestions = quiz.questions.length;
    let correctAnswers = 0;
    
    quiz.questions.forEach((question: any) => {
      if (answers[question.id] === question.correctAnswer) {
        correctAnswers++;
      }
    });
    
    const score = Math.round((correctAnswers / totalQuestions) * 100);
    
    // In a real app, we would send the results to the server here
    
    // Navigate to results page
    navigate(`/results/${quiz.id}`, { 
      state: { 
        score,
        totalQuestions,
        correctAnswers,
        answers,
        quizTitle: quiz.title,
        quizCategory: quiz.category,
        timeTaken: (quiz.timeLimit * 60) - timeLeft
      } 
    });
  };
  
  // Show loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-800 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading quiz...</p>
        </div>
      </div>
    );
  }
  
  // Show error state
  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full">
          <div className="flex items-center justify-center mb-4">
            <AlertCircle className="h-12 w-12 text-red-500" />
          </div>
          <h2 className="text-2xl font-bold text-center text-gray-900 mb-4">Quiz Not Found</h2>
          <p className="text-gray-600 text-center mb-6">
            The quiz you're looking for doesn't exist or has been removed.
          </p>
          <div className="flex justify-center">
            <button
              onClick={() => navigate('/quizzes')}
              className="bg-green-800 text-white px-4 py-2 rounded-md hover:bg-green-700 transition"
            >
              Browse Quizzes
            </button>
          </div>
        </div>
      </div>
    );
  }
  
  // Current question data
  const question = quiz.questions[currentQuestion];
  
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quiz header */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-xl font-bold text-gray-900">{quiz.title}</h1>
              <p className="text-sm text-gray-500 mt-1">
                {quiz.category} • {quiz.totalQuestions} questions
              </p>
            </div>
            <div className="mt-4 md:mt-0 flex items-center">
              <div className={`flex items-center px-3 py-1.5 rounded-md ${
                timeLeft < 60 ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
              }`}>
                <Clock className="h-5 w-5 mr-1" />
                <span className="font-medium">{formatTime(timeLeft)}</span>
              </div>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-500">
                Question {currentQuestion + 1} of {quiz.totalQuestions}
              </div>
              <div className="flex items-center">
                <button
                  onClick={() => toggleFlag(question.id)}
                  className={`flex items-center px-2 py-1 rounded-md mr-2 ${
                    flagged.includes(question.id) 
                      ? 'bg-yellow-100 text-yellow-800' 
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  <Flag className="h-4 w-4 mr-1" />
                  <span className="text-sm">Flag</span>
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Question and answers */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <h2 className="text-lg font-medium text-gray-900 mb-6">
            {question.text}
          </h2>
          
          <div className="space-y-4">
            {question.options.map((option: any) => (
              <div key={option.id}>
                <label className={`flex items-start p-4 border rounded-md cursor-pointer transition ${
                  answers[question.id] === option.id 
                    ? 'border-green-500 bg-green-50' 
                    : 'border-gray-300 hover:bg-gray-50'
                }`}>
                  <input
                    type="radio"
                    name={`question-${question.id}`}
                    value={option.id}
                    checked={answers[question.id] === option.id}
                    onChange={() => handleAnswerSelect(question.id, option.id)}
                    className="h-5 w-5 text-green-600 mt-0.5"
                  />
                  <span className="ml-3 text-gray-900">{option.text}</span>
                </label>
              </div>
            ))}
          </div>
        </div>
        
        {/* Navigation buttons */}
        <div className="flex justify-between">
          <button
            onClick={goToPrevQuestion}
            disabled={currentQuestion === 0}
            className={`flex items-center px-4 py-2 rounded-md ${
              currentQuestion === 0
                ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
            }`}
          >
            <ChevronLeft className="h-5 w-5 mr-1" />
            Previous
          </button>
          
          {currentQuestion < quiz.questions.length - 1 ? (
            <button
              onClick={goToNextQuestion}
              className="flex items-center px-4 py-2 bg-green-800 text-white rounded-md hover:bg-green-700"
            >
              Next
              <ChevronRight className="h-5 w-5 ml-1" />
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={isSubmitting}
              className={`flex items-center px-4 py-2 bg-green-800 text-white rounded-md hover:bg-green-700 ${
                isSubmitting ? 'opacity-70 cursor-not-allowed' : ''
              }`}
            >
              {isSubmitting ? 'Submitting...' : 'Submit Quiz'}
            </button>
          )}
        </div>
        
        {/* Question navigation */}
        <div className="mt-8">
          <h3 className="text-sm font-medium text-gray-700 mb-3">Question Navigation</h3>
          <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
            {quiz.questions.map((_: any, index: number) => (
              <button
                key={index}
                onClick={() => goToQuestion(index)}
                className={`h-10 w-full flex items-center justify-center rounded-md text-sm font-medium ${
                  currentQuestion === index
                    ? 'bg-green-800 text-white'
                    : answers[quiz.questions[index].id]
                      ? 'bg-green-100 text-green-800 border border-green-300'
                      : flagged.includes(quiz.questions[index].id)
                        ? 'bg-yellow-100 text-yellow-800 border border-yellow-300'
                        : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                }`}
              >
                {index + 1}
                {flagged.includes(quiz.questions[index].id) && (
                  <Flag className="h-3 w-3 ml-1" />
                )}
              </button>
            ))}
          </div>
          <div className="mt-4 flex items-center justify-center space-x-6 text-sm">
            <div className="flex items-center">
              <div className="h-4 w-4 bg-green-100 border border-green-300 rounded-sm mr-2"></div>
              <span className="text-gray-600">Answered</span>
            </div>
            <div className="flex items-center">
              <div className="h-4 w-4 bg-yellow-100 border border-yellow-300 rounded-sm mr-2"></div>
              <span className="text-gray-600">Flagged</span>
            </div>
            <div className="flex items-center">
              <div className="h-4 w-4 bg-gray-100 border border-gray-300 rounded-sm mr-2"></div>
              <span className="text-gray-600">Unanswered</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Quiz;