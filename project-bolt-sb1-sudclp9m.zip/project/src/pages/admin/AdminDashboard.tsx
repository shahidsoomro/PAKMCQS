import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { 
  Users, BookOpen, Award, BarChart2, Clock, 
  PlusCircle, Edit, Trash, Download, Settings 
} from 'lucide-react';

// Mock data for admin dashboard
const mockStats = {
  totalUsers: 256,
  totalQuizzes: 12,
  totalQuestions: 320,
  totalAttempts: 1845,
  averageScore: 76,
  activeUsers: 128
};

const mockRecentUsers = [
  { id: '1', name: 'Ahmed Khan', email: 'ahmed@example.com', joinDate: '2023-04-10', quizzesTaken: 5 },
  { id: '2', name: 'Sara Fatima', email: 'sara@example.com', joinDate: '2023-04-11', quizzesTaken: 3 },
  { id: '3', name: 'Usman Malik', email: 'usman@example.com', joinDate: '2023-04-12', quizzesTaken: 7 },
  { id: '4', name: 'Ayesha Ahmed', email: 'ayesha@example.com', joinDate: '2023-04-13', quizzesTaken: 2 },
  { id: '5', name: 'Bilal Hassan', email: 'bilal@example.com', joinDate: '2023-04-14', quizzesTaken: 4 }
];

const mockRecentQuizzes = [
  { 
    id: '101', 
    title: 'Pakistan Independence Movement', 
    category: 'History',
    questions: 20,
    attempts: 145,
    averageScore: 82,
    createdAt: '2023-04-05'
  },
  { 
    id: '102', 
    title: 'Geography of Pakistan', 
    category: 'Geography',
    questions: 15,
    attempts: 98,
    averageScore: 75,
    createdAt: '2023-04-07'
  },
  { 
    id: '103', 
    title: 'Political System of Pakistan', 
    category: 'Politics',
    questions: 25,
    attempts: 112,
    averageScore: 68,
    createdAt: '2023-04-09'
  }
];

const AdminDashboard: React.FC = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState(mockStats);
  const [recentUsers, setRecentUsers] = useState(mockRecentUsers);
  const [recentQuizzes, setRecentQuizzes] = useState(mockRecentQuizzes);
  
  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  };
  
  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page header */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
              <p className="text-gray-600 mt-1">
                Welcome back, {user?.name}. Here's what's happening with your platform.
              </p>
            </div>
            <div className="mt-4 md:mt-0 flex space-x-3">
              <Link 
                to="/admin/quizzes"
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-800 hover:bg-green-700"
              >
                <PlusCircle className="h-4 w-4 mr-2" />
                New Quiz
              </Link>
              <button
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
              >
                <Download className="h-4 w-4 mr-2" />
                Export Data
              </button>
            </div>
          </div>
        </div>
        
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {/* Total Users */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="bg-blue-100 p-3 rounded-full">
                <Users className="h-6 w-6 text-blue-800" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">Total Users</h2>
                <p className="text-2xl font-semibold text-gray-900">{stats.totalUsers}</p>
                <p className="text-sm text-gray-500 mt-1">
                  <span className="text-green-600">{stats.activeUsers}</span> active this month
                </p>
              </div>
            </div>
          </div>
          
          {/* Total Quizzes */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="bg-green-100 p-3 rounded-full">
                <BookOpen className="h-6 w-6 text-green-800" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">Total Quizzes</h2>
                <p className="text-2xl font-semibold text-gray-900">{stats.totalQuizzes}</p>
                <p className="text-sm text-gray-500 mt-1">
                  <span className="text-green-600">{stats.totalQuestions}</span> questions in total
                </p>
              </div>
            </div>
          </div>
          
          {/* Quiz Attempts */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="bg-purple-100 p-3 rounded-full">
                <Award className="h-6 w-6 text-purple-800" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">Quiz Attempts</h2>
                <p className="text-2xl font-semibold text-gray-900">{stats.totalAttempts}</p>
                <p className="text-sm text-gray-500 mt-1">
                  <span className="text-green-600">{stats.averageScore}%</span> average score
                </p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Users */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
              <h2 className="text-lg font-semibold text-gray-900">Recent Users</h2>
              <Link 
                to="#"
                className="text-sm font-medium text-green-800 hover:text-green-700"
              >
                View All
              </Link>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Name
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Join Date
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Quizzes
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {recentUsers.map(user => (
                    <tr key={user.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center mr-3">
                            <span className="text-sm font-medium text-green-800">
                              {user.name.split(' ').map(n => n[0]).join('')}
                            </span>
                          </div>
                          <div>
                            <div className="text-sm font-medium text-gray-900">{user.name}</div>
                            <div className="text-sm text-gray-500">{user.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{formatDate(user.joinDate)}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{user.quizzesTaken}</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-2">
                          <button className="text-indigo-600 hover:text-indigo-900">
                            <Edit className="h-4 w-4" />
                          </button>
                          <button className="text-red-600 hover:text-red-900">
                            <Trash className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          
          {/* Recent Quizzes */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
              <h2 className="text-lg font-semibold text-gray-900">Recent Quizzes</h2>
              <Link 
                to="/admin/quizzes"
                className="text-sm font-medium text-green-800 hover:text-green-700"
              >
                View All
              </Link>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Title
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Category
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Attempts
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {recentQuizzes.map(quiz => (
                    <tr key={quiz.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                          <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center mr-3">
                            <BookOpen className="h-4 w-4 text-green-800" />
                          </div>
                          <div>
                            <div className="text-sm font-medium text-gray-900">{quiz.title}</div>
                            <div className="text-sm text-gray-500">{quiz.questions} questions</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                          {quiz.category}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">{quiz.attempts}</div>
                        <div className="text-sm text-gray-500">{quiz.averageScore}% avg. score</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex space-x-2">
                          <Link 
                            to={`/admin/questions/${quiz.id}`}
                            className="text-indigo-600 hover:text-indigo-900"
                          >
                            <Edit className="h-4 w-4" />
                          </Link>
                          <button className="text-red-600 hover:text-red-900">
                            <Trash className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;