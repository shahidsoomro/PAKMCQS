import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  BookOpen, PlusCircle, Edit, Trash, Save, 
  ArrowLeft, HelpCircle, Check, X, AlertCircle 
} from 'lucide-react';

// Mock quiz data
const mockQuizData = {
  '101': {
    id: '101',
    title: 'Pakistan Independence Movement',
    category: 'History',
    description: 'Test your knowledge about the events leading to Pakistan\'s independence in 1947.',
    timeLimit: 15,
    status: 'Published',
    questions: [
      {
        id: 1,
        text: 'When was Pakistan officially declared an independent nation?',
        options: [
          { id: 'a', text: 'August 14, 1947' },
          { id: 'b', text: 'August 15, 1947' },
          { id: 'c', text: 'March 23, 1940' },
          { id: 'd', text: 'June 3, 1947' }
        ],
        correctAnswer: 'a'
      },
      {
        id: 2,
        text: 'Who was the first Governor-General of Pakistan?',
        options: [
          { id: 'a', text: 'Liaquat Ali Khan' },
          { id: 'b', text: 'Muhammad Ali Jinnah' },
          { id: 'c', text: 'Khawaja Nazimuddin' },
          { id: 'd', text: 'Iskander Mirza' }
        ],
        correctAnswer: 'b'
      },
      {
        id: 3,
        text: 'Which resolution is considered the basis for the creation of Pakistan?',
        options: [
          { id: 'a', text: 'Delhi Resolution' },
          { id: 'b', text: 'Lahore Resolution' },
          { id: 'c', text: 'Karachi Resolution' },
          { id: 'd', text: 'Rawalpindi Resolution' }
        ],
        correctAnswer: 'b'
      }
    ]
  }
};

const AdminQuestions: React.FC = () => {
  const { quizId } = useParams<{ quizId: string }>();
  const navigate = useNavigate();
  
  const [quiz, setQuiz] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [questions, setQuestions] = useState<any[]>([]);
  const [editingQuestion, setEditingQuestion] = useState<any>(null);
  const [showQuestionModal, setShowQuestionModal] = useState(false);
  const [newQuestion, setNewQuestion] = useState({
    text: '',
    options: [
      { id: 'a', text: '' },
      { id: 'b', text: '' },
      { id: 'c', text: '' },
      { id: 'd', text: '' }
    ],
    correctAnswer: 'a'
  });
  
  // Fetch quiz data
  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      if (quizId && mockQuizData[quizId]) {
        setQuiz(mockQuizData[quizId]);
        setQuestions(mockQuizData[quizId].questions);
        setLoading(false);
      } else {
        setError('Quiz not found');
        setLoading(false);
      }
    }, 1000);
  }, [quizId]);
  
  // Handle add question
  const handleAddQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate question
    if (!newQuestion.text.trim()) {
      alert('Please enter a question');
      return;
    }
    
    // Validate options
    for (const option of newQuestion.options) {
      if (!option.text.trim()) {
        alert('Please fill in all options');
        return;
      }
    }
    
    // Create new question
    const questionToAdd = {
      id: questions.length > 0 ? Math.max(...questions.map(q => q.id)) + 1 : 1,
      ...newQuestion
    };
    
    // Add to questions
    setQuestions([...questions, questionToAdd]);
    
    // Reset form
    setNewQuestion({
      text: '',
      options: [
        { id: 'a', text: '' },
        { id: 'b', text: '' },
        { id: 'c', text: '' },
        { id: 'd', text: '' }
      ],
      correctAnswer: 'a'
    });
    
    // Close modal
    setShowQuestionModal(false);
  };
  
  // Handle edit question
  const handleEditQuestion = (question: any) => {
    setEditingQuestion(question);
    setNewQuestion({
      text: question.text,
      options: [...question.options],
      correctAnswer: question.correctAnswer
    });
    setShowQuestionModal(true);
  };
  
  // Handle update question
  const handleUpdateQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate question
    if (!newQuestion.text.trim()) {
      alert('Please enter a question');
      return;
    }
    
    // Validate options
    for (const option of newQuestion.options) {
      if (!option.text.trim()) {
        alert('Please fill in all options');
        return;
      }
    }
    
    // Update question
    const updatedQuestions = questions.map(q => {
      if (q.id === editingQuestion.id) {
        return {
          ...q,
          text: newQuestion.text,
          options: newQuestion.options,
          correctAnswer: newQuestion.correctAnswer
        };
      }
      return q;
    });
    
    setQuestions(updatedQuestions);
    
    // Reset form
    setNewQuestion({
      text: '',
      options: [
        { id: 'a', text: '' },
        { id: 'b', text: '' },
        { id: 'c', text: '' },
        { id: 'd', text: '' }
      ],
      correctAnswer: 'a'
    });
    
    // Close modal
    setShowQuestionModal(false);
    setEditingQuestion(null);
  };
  
  // Handle delete question
  const handleDeleteQuestion = (id: number) => {
    if (window.confirm('Are you sure you want to delete this question?')) {
      setQuestions(questions.filter(q => q.id !== id));
    }
  };
  
  // Handle option change
  const handleOptionChange = (optionId: string, value: string) => {
    setNewQuestion({
      ...newQuestion,
      options: newQuestion.options.map(opt => 
        opt.id === optionId ? { ...opt, text: value } : opt
      )
    });
  };
  
  // Handle save quiz
  const handleSaveQuiz = () => {
    // In a real app, we would send this to the server
    alert('Quiz saved successfully!');
    navigate('/admin/quizzes');
  };
  
  // Show loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-800 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading quiz...</p>
        </div>
      </div>
    );
  }
  
  // Show error state
  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-md max-w-md w-full">
          <div className="flex items-center justify-center mb-4">
            <AlertCircle className="h-12 w-12 text-red-500" />
          </div>
          <h2 className="text-2xl font-bold text-center text-gray-900 mb-4">Quiz Not Found</h2>
          <p className="text-gray-600 text-center mb-6">
            The quiz you're looking for doesn't exist or has been removed.
          </p>
          <div className="flex justify-center">
            <Link
              to="/admin/quizzes"
              className="bg-green-800 text-white px-4 py-2 rounded-md hover:bg-green-700 transition"
            >
              Back to Quizzes
            </Link>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page header */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <div className="flex items-center mb-2">
                <Link 
                  to="/admin/quizzes"
                  className="text-green-800 hover:text-green-700 mr-2"
                >
                  <ArrowLeft className="h-5 w-5" />
                </Link>
                <h1 className="text-2xl font-bold text-gray-900">Edit Quiz Questions</h1>
              </div>
              <p className="text-gray-600">
                {quiz.title} • {quiz.category} • {questions.length} questions
              </p>
            </div>
            <div className="mt-4 md:mt-0 flex space-x-3">
              <button
                onClick={() => {
                  setEditingQuestion(null);
                  setNewQuestion({
                    text: '',
                    options: [
                      { id: 'a', text: '' },
                      { id: 'b', text: '' },
                      { id: 'c', text: '' },
                      { id: 'd', text: '' }
                    ],
                    correctAnswer: 'a'
                  });
                  setShowQuestionModal(true);
                }}
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-800 hover:bg-green-700"
              >
                <PlusCircle className="h-4 w-4 mr-2" />
                Add Question
              </button>
              <button
                onClick={handleSaveQuiz}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
              >
                <Save className="h-4 w-4 mr-2" />
                Save Quiz
              </button>
            </div>
          </div>
        </div>
        
        {/* Questions list */}
        <div className="space-y-6">
          {questions.length > 0 ? (
            questions.map((question, index) => (
              <div key={question.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center bg-gray-50">
                  <h3 className="text-lg font-medium text-gray-900">
                    Question {index + 1}
                  </h3>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleEditQuestion(question)}
                      className="text-indigo-600 hover:text-indigo-900"
                    >
                      <Edit className="h-5 w-5" />
                    </button>
                    <button
                      onClick={() => handleDeleteQuestion(question.id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      <Trash className="h-5 w-5" />
                    </button>
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-gray-900 font-medium mb-4">{question.text}</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {question.options.map((option: any) => (
                      <div 
                        key={option.id}
                        className={`p-4 border rounded-md ${
                          option.id === question.correctAnswer 
                            ? 'border-green-500 bg-green-50' 
                            : 'border-gray-300'
                        }`}
                      >
                        <div className="flex items-start">
                          <div className={`flex items-center justify-center h-6 w-6 rounded-full text-sm font-medium mr-3 ${
                            option.id === question.correctAnswer 
                              ? 'bg-green-500 text-white' 
                              : 'bg-gray-200 text-gray-700'
                          }`}>
                            {option.id.toUpperCase()}
                          </div>
                          <span className="text-gray-900">{option.text}</span>
                          {option.id === question.correctAnswer && (
                            <Check className="h-5 w-5 text-green-500 ml-auto" />
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <HelpCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Questions Yet</h3>
              <p className="text-gray-500 mb-6">
                This quiz doesn't have any questions yet. Click the button below to add your first question.
              </p>
              <button
                onClick={() => {
                  setEditingQuestion(null);
                  setNewQuestion({
                    text: '',
                    options: [
                      { id: 'a', text: '' },
                      { id: 'b', text: '' },
                      { id: 'c', text: '' },
                      { id: 'd', text: '' }
                    ],
                    correctAnswer: 'a'
                  });
                  setShowQuestionModal(true);
                }}
                className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-800 hover:bg-green-700"
              >
                <PlusCircle className="h-4 w-4 mr-2" />
                Add First Question
              </button>
            </div>
          )}
        </div>
      </div>
      
      {/* Question Modal */}
      {showQuestionModal && (
        <div className="fixed inset-0 overflow-y-auto z-50">
          <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity" aria-hidden="true">
              <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>
            
            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            
            <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
              <form onSubmit={editingQuestion ? handleUpdateQuestion : handleAddQuestion}>
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                  <div className="sm:flex sm:items-start">
                    <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                      <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
                        {editingQuestion ? 'Edit Question' : 'Add New Question'}
                      </h3>
                      
                      <div className="mb-4">
                        <label htmlFor="questionText" className="block text-sm font-medium text-gray-700 mb-1">
                          Question Text
                        </label>
                        <textarea
                          id="questionText"
                          value={newQuestion.text}
                          onChange={(e) => setNewQuestion({...newQuestion, text: e.target.value})}
                          rows={3}
                          className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                          required
                        ></textarea>
                      </div>
                      
                      <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Answer Options
                        </label>
                        
                        {newQuestion.options.map((option) => (
                          <div key={option.id} className="flex items-center mb-3">
                            <div className={`flex items-center justify-center h-6 w-6 rounded-full text-sm font-medium mr-3 ${
                              option.id === newQuestion.correctAnswer 
                                ? 'bg-green-500 text-white' 
                                : 'bg-gray-200 text-gray-700'
                            }`}>
                              {option.id.toUpperCase()}
                            </div>
                            <input
                              type="text"
                              value={option.text}
                              onChange={(e) => handleOptionChange(option.id, e.target.value)}
                              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
                              placeholder={`Option ${option.id.toUpperCase()}`}
                              required
                            />
                            <button
                              type="button"
                              onClick={() => setNewQuestion({...newQuestion, correctAnswer: option.id})}
                              className={`ml-2 p-2 rounded-md ${
                                option.id === newQuestion.correctAnswer 
                                  ? 'bg-green-100 text-green-800' 
                                  : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                              }`}
                              title="Set as correct answer"
                            >
                              {option.id === newQuestion.correctAnswer ? (
                                <Check className="h-5 w-5" />
                              ) : (
                                <span className="h-5 w-5 block"></span>
                              )}
                            </button>
                          </div>
                        ))}
                        
                        <p className="text-sm text-gray-500 mt-2">
                          Click the button next to an option to mark it as the correct answer.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                  <button
                    type="submit"
                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-green-800 text-base font-medium text-white hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    {editingQuestion ? 'Update Question' : 'Add Question'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowQuestionModal(false);
                      setEditingQuestion(null);
                    }}
                    className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminQuestions;