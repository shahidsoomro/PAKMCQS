import React, { useState, useEffect } from 'react';
import { Trophy, Medal, Filter, Search, ChevronDown, User } from 'lucide-react';

// Mock data for leaderboard
const mockLeaderboardData = [
  {
    id: '1',
    name: 'Ahmed Khan',
    quizzes: 15,
    averageScore: 92,
    highestScore: 98,
    badges: 8,
    lastActive: '2023-04-10'
  },
  {
    id: '2',
    name: 'Sara Fatima',
    quizzes: 12,
    averageScore: 88,
    highestScore: 95,
    badges: 6,
    lastActive: '2023-04-12'
  },
  {
    id: '3',
    name: 'Usman Malik',
    quizzes: 18,
    averageScore: 85,
    highestScore: 92,
    badges: 7,
    lastActive: '2023-04-08'
  },
  {
    id: '4',
    name: 'Ayesha Ahmed',
    quizzes: 10,
    averageScore: 83,
    highestScore: 90,
    badges: 5,
    lastActive: '2023-04-11'
  },
  {
    id: '5',
    name: 'Bilal Hassan',
    quizzes: 14,
    averageScore: 81,
    highestScore: 88,
    badges: 6,
    lastActive: '2023-04-09'
  },
  {
    id: '6',
    name: 'Fatima Zahra',
    quizzes: 9,
    averageScore: 79,
    highestScore: 86,
    badges: 4,
    lastActive: '2023-04-13'
  },
  {
    id: '7',
    name: 'Hassan Ali',
    quizzes: 11,
    averageScore: 77,
    highestScore: 85,
    badges: 5,
    lastActive: '2023-04-07'
  },
  {
    id: '8',
    name: 'Zainab Khan',
    quizzes: 8,
    averageScore: 75,
    highestScore: 82,
    badges: 3,
    lastActive: '2023-04-14'
  },
  {
    id: '9',
    name: 'Imran Malik',
    quizzes: 13,
    averageScore: 73,
    highestScore: 80,
    badges: 4,
    lastActive: '2023-04-06'
  },
  {
    id: '10',
    name: 'Nadia Hussain',
    quizzes: 7,
    averageScore: 70,
    highestScore: 78,
    badges: 2,
    lastActive: '2023-04-15'
  }
];

// Categories for filtering
const categories = [
  'All Categories',
  'History',
  'Geography',
  'Politics',
  'Culture',
  'Economy'
];

// Time periods for filtering
const timePeriods = [
  'All Time',
  'This Week',
  'This Month',
  'This Year'
];

const Leaderboard: React.FC = () => {
  const [leaderboard, setLeaderboard] = useState(mockLeaderboardData);
  const [filteredLeaderboard, setFilteredLeaderboard] = useState(mockLeaderboardData);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [selectedTimePeriod, setSelectedTimePeriod] = useState('All Time');
  const [sortBy, setSortBy] = useState('score'); // 'score', 'quizzes', 'badges'
  
  // Apply filters and search
  useEffect(() => {
    let result = [...leaderboard];
    
    // Apply search
    if (searchTerm) {
      result = result.filter(user => 
        user.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    // Apply sorting
    if (sortBy === 'score') {
      result.sort((a, b) => b.averageScore - a.averageScore);
    } else if (sortBy === 'quizzes') {
      result.sort((a, b) => b.quizzes - a.quizzes);
    } else if (sortBy === 'badges') {
      result.sort((a, b) => b.badges - a.badges);
    }
    
    setFilteredLeaderboard(result);
  }, [leaderboard, searchTerm, selectedCategory, selectedTimePeriod, sortBy]);
  
  // Get medal color based on rank
  const getMedalColor = (index: number) => {
    if (index === 0) return 'text-yellow-500'; // Gold
    if (index === 1) return 'text-gray-400'; // Silver
    if (index === 2) return 'text-amber-700'; // Bronze
    return 'text-gray-300'; // No medal
  };
  
  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Leaderboard</h1>
          <p className="mt-2 text-gray-600">
            See how you rank among other students and compete for the top positions.
          </p>
        </div>
        
        {/* Top performers */}
        <div className="mb-12">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Top Performers</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {filteredLeaderboard.slice(0, 3).map((user, index) => (
              <div key={user.id} className="bg-white rounded-lg shadow-md overflow-hidden">
                <div className="bg-green-800 text-white p-4 text-center">
                  <div className="flex justify-center mb-2">
                    {index === 0 ? (
                      <Trophy className="h-10 w-10 text-yellow-300" />
                    ) : (
                      <Medal className={`h-10 w-10 ${getMedalColor(index)}`} />
                    )}
                  </div>
                  <h3 className="text-lg font-semibold">
                    {index === 0 ? '1st Place' : index === 1 ? '2nd Place' : '3rd Place'}
                  </h3>
                </div>
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center mr-4">
                      <User className="h-6 w-6 text-green-800" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{user.name}</h4>
                      <p className="text-sm text-gray-500">{user.quizzes} quizzes completed</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Average Score</p>
                      <p className="text-lg font-semibold text-gray-900">{user.averageScore}%</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Badges</p>
                      <p className="text-lg font-semibold text-gray-900">{user.badges}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Filters and search */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {/* Search */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search users..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm"
              />
            </div>
            
            {/* Category filter */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter className="h-5 w-5 text-gray-400" />
              </div>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm appearance-none"
              >
                {categories.map(category => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <ChevronDown className="h-5 w-5 text-gray-400" />
              </div>
            </div>
            
            {/* Time period filter */}
            <div className="relative">
              <select
                value={selectedTimePeriod}
                onChange={(e) => setSelectedTimePeriod(e.target.value)}
                className="block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm appearance-none"
              >
                {timePeriods.map(period => (
                  <option key={period} value={period}>{period}</option>
                ))}
              </select>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <ChevronDown className="h-5 w-5 text-gray-400" />
              </div>
            </div>
            
            {/* Sort by */}
            <div className="relative">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 sm:text-sm appearance-none"
              >
                <option value="score">Highest Score</option>
                <option value="quizzes">Most Quizzes</option>
                <option value="badges">Most Badges</option>
              </select>
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                <ChevronDown className="h-5 w-5 text-gray-400" />
              </div>
            </div>
          </div>
        </div>
        
        {/* Leaderboard table */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Rank
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    User
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Quizzes
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Avg. Score
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Highest Score
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Badges
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Last Active
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredLeaderboard.map((user, index) => (
                  <tr key={user.id} className={index < 3 ? 'bg-green-50' : ''}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <span className="text-sm font-medium text-gray-900 mr-2">{index + 1}</span>
                        {index < 3 && (
                          <Medal className={`h-5 w-5 ${getMedalColor(index)}`} />
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center mr-3">
                          <span className="text-sm font-medium text-green-800">
                            {user.name.split(' ').map(n => n[0]).join('')}
                          </span>
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-900">{user.name}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{user.quizzes}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{user.averageScore}%</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{user.highestScore}%</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{user.badges}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">
                        {new Date(user.lastActive).toLocaleDateString()}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Leaderboard;