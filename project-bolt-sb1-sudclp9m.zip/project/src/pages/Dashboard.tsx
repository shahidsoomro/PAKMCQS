import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { Award, BarChart2, BookOpen, Clock, Trophy, CheckCircle, Calendar } from 'lucide-react';
import { format } from 'date-fns';

const mockQuizAttempts = [
  {
    id: '1',
    quizId: '101',
    quizTitle: 'Pakistan Independence Movement',
    category: 'History',
    score: 85,
    totalQuestions: 20,
    date: new Date(2023, 3, 15),
    timeTaken: '12:45',
    certificate: true
  },
  {
    id: '2',
    quizId: '102',
    quizTitle: 'Geography of Pakistan',
    category: 'Geography',
    score: 75,
    totalQuestions: 15,
    date: new Date(2023, 3, 10),
    timeTaken: '10:30',
    certificate: true
  },
  {
    id: '3',
    quizId: '103',
    quizTitle: 'Political System of Pakistan',
    category: 'Politics',
    score: 90,
    totalQuestions: 25,
    date: new Date(2023, 3, 5),
    timeTaken: '18:20',
    certificate: true
  }
];

const mockBadges = [
  {
    id: '1',
    title: 'History Expert',
    description: 'Completed 5 history quizzes with 80%+ score',
    icon: <BookOpen className="h-8 w-8 text-green-800" />,
    earned: true,
    date: new Date(2023, 2, 20)
  },
  {
    id: '2',
    title: 'Quiz Master',
    description: 'Completed 10 quizzes in total',
    icon: <Trophy className="h-8 w-8 text-green-800" />,
    earned: true,
    date: new Date(2023, 3, 5)
  },
  {
    id: '3',
    title: 'Perfect Score',
    description: 'Achieved 100% in any quiz',
    icon: <Award className="h-8 w-8 text-green-800" />,
    earned: false,
    date: null
  }
];

const mockRecommendedQuizzes = [
  {
    id: '201',
    title: 'Cultural Heritage of Pakistan',
    category: 'Culture',
    questions: 20,
    difficulty: 'Medium',
    estimatedTime: '15 mins'
  },
  {
    id: '202',
    title: 'Economic Development of Pakistan',
    category: 'Economy',
    questions: 15,
    difficulty: 'Hard',
    estimatedTime: '12 mins'
  },
  {
    id: '203',
    title: 'Pakistan\'s Foreign Relations',
    category: 'Politics',
    questions: 25,
    difficulty: 'Medium',
    estimatedTime: '20 mins'
  }
];

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const [quizAttempts, setQuizAttempts] = useState(mockQuizAttempts);
  const [badges, setBadges] = useState(mockBadges);
  const [recommendedQuizzes, setRecommendedQuizzes] = useState(mockRecommendedQuizzes);
  const [stats, setStats] = useState({
    totalQuizzes: 3,
    averageScore: 83,
    totalCertificates: 3,
    highestScore: 90
  });

  useEffect(() => {
    if (quizAttempts.length > 0) {
      const totalScore = quizAttempts.reduce((sum, quiz) => sum + quiz.score, 0);
      const avgScore = Math.round(totalScore / quizAttempts.length);
      const highestScore = Math.max(...quizAttempts.map(quiz => quiz.score));
      const certificates = quizAttempts.filter(quiz => quiz.certificate).length;
      
      setStats({
        totalQuizzes: quizAttempts.length,
        averageScore: avgScore,
        totalCertificates: certificates,
        highestScore: highestScore
      });
    }
  }, [quizAttempts]);

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome section */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Welcome back, {user?.name}!</h1>
          <p className="text-gray-600 mt-2">
            Track your progress, earn certificates, and continue your journey in Pakistan Studies.
          </p>
        </div>
        
        {/* Stats section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* Total Quizzes */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="bg-green-100 p-3 rounded-full">
                <BookOpen className="h-6 w-6 text-green-800" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">Total Quizzes</h2>
                <p className="text-2xl font-semibold text-gray-900">{stats.totalQuizzes}</p>
              </div>
            </div>
          </div>
          
          {/* Average Score */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="bg-green-100 p-3 rounded-full">
                <BarChart2 className="h-6 w-6 text-green-800" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">Average Score</h2>
                <p className="text-2xl font-semibold text-gray-900">{stats.averageScore}%</p>
              </div>
            </div>
          </div>
          
          {/* Certificates */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="bg-green-100 p-3 rounded-full">
                <Award className="h-6 w-6 text-green-800" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">Certificates</h2>
                <p className="text-2xl font-semibold text-gray-900">{stats.totalCertificates}</p>
              </div>
            </div>
          </div>
          
          {/* Highest Score */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center">
              <div className="bg-green-100 p-3 rounded-full">
                <Trophy className="h-6 w-6 text-green-800" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">Highest Score</h2>
                <p className="text-2xl font-semibold text-gray-900">{stats.highestScore}%</p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Main content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Quiz Attempts */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">Recent Quiz Attempts</h2>
              </div>
              <div className="divide-y divide-gray-200">
                {quizAttempts.length > 0 ? (
                  quizAttempts.map(quiz => (
                    <div key={quiz.id} className="px-6 py-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="text-md font-medium text-gray-900">{quiz.quizTitle}</h3>
                          <p className="text-sm text-gray-500">{quiz.category}</p>
                          <div className="flex items-center mt-2 text-sm text-gray-500">
                            <Calendar className="h-4 w-4 mr-1" />
                            <span>{format(quiz.date, 'MMM d, yyyy')}</span>
                            <Clock className="h-4 w-4 ml-3 mr-1" />
                            <span>{quiz.timeTaken}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            {quiz.score}%
                          </div>
                          <p className="text-sm text-gray-500 mt-1">
                            {Math.round(quiz.score / 100 * quiz.totalQuestions)}/{quiz.totalQuestions} correct
                          </p>
                          {quiz.certificate && (
                            <Link 
                              to={`/results/${quiz.id}`}
                              className="inline-flex items-center mt-2 text-sm font-medium text-green-800 hover:text-green-700"
                            >
                              <Award className="h-4 w-4 mr-1" />
                              View Certificate
                            </Link>
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="px-6 py-4 text-center text-gray-500">
                    <p>You haven't attempted any quizzes yet.</p>
                  </div>
                )}
              </div>
              <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
                <Link 
                  to="/quizzes"
                  className="text-sm font-medium text-green-800 hover:text-green-700"
                >
                  View all quiz attempts →
                </Link>
              </div>
            </div>
            
            {/* Recommended Quizzes */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden mt-8">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">Recommended Quizzes</h2>
              </div>
              <div className="divide-y divide-gray-200">
                {recommendedQuizzes.map(quiz => (
                  <div key={quiz.id} className="px-6 py-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="text-md font-medium text-gray-900">{quiz.title}</h3>
                        <div className="flex items-center mt-1">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 mr-2">
                            {quiz.category}
                          </span>
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800 mr-2">
                            {quiz.difficulty}
                          </span>
                          <span className="text-sm text-gray-500">
                            <Clock className="inline h-4 w-4 mr-1" />
                            {quiz.estimatedTime}
                          </span>
                        </div>
                      </div>
                      <Link 
                        to={`/quiz/${quiz.id}`}
                        className="inline-flex items-center px-3 py-1.5 border border-transparent text-sm font-medium rounded-md text-white bg-green-800 hover:bg-green-700"
                      >
                        Start Quiz
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
              <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
                <Link 
                  to="/quizzes"
                  className="text-sm font-medium text-green-800 hover:text-green-700"
                >
                  Browse all quizzes →
                </Link>
              </div>
            </div>
          </div>
          
          {/* Badges and Achievements */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">Badges & Achievements</h2>
              </div>
              <div className="divide-y divide-gray-200">
                {badges.map(badge => (
                  <div key={badge.id} className="px-6 py-4">
                    <div className="flex items-center">
                      <div className={`p-2 rounded-full ${badge.earned ? 'bg-green-100' : 'bg-gray-100'}`}>
                        {badge.icon}
                      </div>
                      <div className="ml-4">
                        <div className="flex items-center">
                          <h3 className="text-md font-medium text-gray-900">{badge.title}</h3>
                          {badge.earned && (
                            <CheckCircle className="h-4 w-4 text-green-600 ml-2" />
                          )}
                        </div>
                        <p className="text-sm text-gray-500">{badge.description}</p>
                        {badge.earned && badge.date && (
                          <p className="text-xs text-gray-500 mt-1">
                            Earned on {format(badge.date, 'MMM d, yyyy')}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
                <Link 
                  to="/leaderboard"
                  className="text-sm font-medium text-green-800 hover:text-green-700"
                >
                  View leaderboard →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;