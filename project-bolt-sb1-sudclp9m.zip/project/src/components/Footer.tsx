import React from 'react';
import { BookOpen, Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-green-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and description */}
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center mb-4">
              <BookOpen className="h-8 w-8 mr-2" />
              <span className="font-bold text-xl">PakStudy MCQs</span>
            </div>
            <p className="text-gray-300 mb-4">
              Your ultimate platform for Pakistan Studies MCQs. Practice, learn, and excel in your studies.
            </p>
          </div>
          
          {/* Quick links */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="/" className="text-gray-300 hover:text-white transition">Home</a></li>
              <li><a href="/quizzes" className="text-gray-300 hover:text-white transition">Quizzes</a></li>
              <li><a href="/leaderboard" className="text-gray-300 hover:text-white transition">Leaderboard</a></li>
              <li><a href="/login" className="text-gray-300 hover:text-white transition">Login</a></li>
              <li><a href="/register" className="text-gray-300 hover:text-white transition">Register</a></li>
            </ul>
          </div>
          
          {/* Categories */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Categories</h3>
            <ul className="space-y-2">
              <li><a href="/quizzes" className="text-gray-300 hover:text-white transition">History</a></li>
              <li><a href="/quizzes" className="text-gray-300 hover:text-white transition">Geography</a></li>
              <li><a href="/quizzes" className="text-gray-300 hover:text-white transition">Politics</a></li>
              <li><a href="/quizzes" className="text-gray-300 hover:text-white transition">Culture</a></li>
              <li><a href="/quizzes" className="text-gray-300 hover:text-white transition">Economy</a></li>
            </ul>
          </div>
          
          {/* Contact */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-2">
              <li className="flex items-center">
                <Mail className="h-5 w-5 mr-2" />
                <a href="mailto:info@pakstudy.com" className="text-gray-300 hover:text-white transition">info@pakstudy.com</a>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 mr-2" />
                <a href="tel:+923001234567" className="text-gray-300 hover:text-white transition">+92 300 1234567</a>
              </li>
              <li className="flex items-start">
                <MapPin className="h-5 w-5 mr-2 mt-1" />
                <span className="text-gray-300">Islamabad, Pakistan</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-300 text-sm">
            &copy; {currentYear} PakStudy MCQs. All rights reserved.
          </p>
          <div className="mt-4 md:mt-0">
            <ul className="flex space-x-4">
              <li><a href="#" className="text-gray-300 hover:text-white transition">Privacy Policy</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition">Terms of Service</a></li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;