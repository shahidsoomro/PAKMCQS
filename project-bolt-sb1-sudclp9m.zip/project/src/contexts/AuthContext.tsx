import React, { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';
import { jwtDecode } from 'jwt-decode';

// Define types
interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'student';
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  error: string | null;
}

// Create context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// API URL - would come from environment variables in a real app
const API_URL = 'https://api.example.com'; // Replace with your actual API URL

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Check if user is already logged in
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      try {
        // For demo purposes, we'll decode the token directly
        // In production, you should verify the token with your backend
        const decoded = jwtDecode(token);
        setUser(decoded as User);
      } catch (err) {
        // Token is invalid
        localStorage.removeItem('token');
      }
    }
    setIsLoading(false);
  }, []);

  // Login function
  const login = async (email: string, password: string) => {
    try {
      setError(null);
      setIsLoading(true);
      
      // For demo purposes, we'll simulate a successful login
      // In production, this would be a real API call
      // const response = await axios.post(`${API_URL}/api/auth/login`, { email, password });
      
      // Simulate API response
      const mockResponse = {
        data: {
          token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjEyMzQ1IiwibmFtZSI6IlRlc3QgVXNlciIsImVtYWlsIjoidGVzdEBleGFtcGxlLmNvbSIsInJvbGUiOiJzdHVkZW50In0.8HKCFhvdk0zHZ5l-qnrDXlAI-BzLGfbe_OWYEg2Z1_0',
          user: {
            id: '12345',
            name: 'Test User',
            email: email,
            role: email.includes('admin') ? 'admin' : 'student'
          }
        }
      };
      
      const { token, user } = mockResponse.data;
      
      // Save token to localStorage
      localStorage.setItem('token', token);
      
      // Set user state
      setUser(user);
    } catch (err) {
      setError('Invalid email or password');
      console.error('Login error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Register function
  const register = async (name: string, email: string, password: string) => {
    try {
      setError(null);
      setIsLoading(true);
      
      // For demo purposes, we'll simulate a successful registration
      // In production, this would be a real API call
      // const response = await axios.post(`${API_URL}/api/auth/register`, { name, email, password });
      
      // Simulate API response
      const mockResponse = {
        data: {
          token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjEyMzQ1IiwibmFtZSI6IlRlc3QgVXNlciIsImVtYWlsIjoidGVzdEBleGFtcGxlLmNvbSIsInJvbGUiOiJzdHVkZW50In0.8HKCFhvdk0zHZ5l-qnrDXlAI-BzLGfbe_OWYEg2Z1_0',
          user: {
            id: '12345',
            name: name,
            email: email,
            role: 'student'
          }
        }
      };
      
      const { token, user } = mockResponse.data;
      
      // Save token to localStorage
      localStorage.setItem('token', token);
      
      // Set user state
      setUser(user);
    } catch (err) {
      setError('Registration failed. Please try again.');
      console.error('Registration error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Logout function
  const logout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };

  const value = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    register,
    logout,
    error
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// Custom hook to use auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};